package hotel;

public class User {
	
	int PhoneNumber;
	String Name,Email,Address,Password;
	
	public User(int PhoneNumber,String Name,String Address,String Email,String Password) {	
		this.PhoneNumber=PhoneNumber;
		this.Name=Name;
		this.Address=Address;
		this.Email=Email;
		this.Password=Password;
	}
	


	public int getPhoneNumber() {
		return PhoneNumber;
	}


	public void setPhoneNumber(int phoneNumber) {
		PhoneNumber = phoneNumber;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getEmail() {
		return Email;
	}


	public void setEmail(String email) {
		Email = email;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public String getPassword() {
		return Password;
	}


	public void setPassword(String password) {
		Password = password;
	}

}

package hotel;

public class Bills {

	String foodName;
	int quantity,price;
	
	
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public Bills(String foodName, int quantity, int price) {
		super();
		this.foodName = foodName;
		this.quantity = quantity;
		this.price = price;
	}
	
	
}

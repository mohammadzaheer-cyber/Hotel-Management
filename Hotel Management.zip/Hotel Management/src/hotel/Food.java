package hotel;

import java.util.Scanner;

public class Food {
	
	int qyt=0;
	int bill=0;
	int count=0;

	Bills[] b=new Bills[10];

	Scanner s=new Scanner(System.in);

	public void nonveg() {
		int q;
		do{
			System.out.println("              Non-Veg Pizza Menu                  |");
			System.out.println("|=================================================|");
			System.out.println("|            PizzaName                Price       |");
			System.out.println("|          1.Barbecue Chicken         259/-       |");
			System.out.println("|          2.Chicken fiesta           319/-       |");
			System.out.println("|          3.Chicken Maximus          399/-       |");
			System.out.println("|          4.Chicken Dominator        369/-       |");
			System.out.println("|          5.Chicken Sausage          209/-       |");
			System.out.println("|          6.Chicken Pepperoni        369/-       |");
			System.out.println("|          7.Indi Chicken Tikka       449/-       |");
			System.out.println("|          8.Chicken Golden           379/-       |");
			System.out.println("|          9.Chicken Keema            349/-       |");
			System.out.println("|          10.Chicken Cheese          249/-       |");
			System.out.println("|                                                 |");
			System.out.println("|          Press 0 To Select Other                |");
			System.out.println("|=================================================|");



			int[] nonveg= {0,259,319,399,369,209,369,449,879,349,249};
			int[] Id= {0,1,2,3,4,5,6,7,8,9,10};
			String[] food= {null,"Barbecue Chicken","Chicken fiesta","Chicken Maximus","Chicken Dominator","Chicken Sausage","Chicken Pepperoni","Indi Chicken Tikka","Chicken Golden","Chicken Keema","Chicken Cheese "};
			q=s.nextInt();
			if(Id[q]==q && Id[q]!=0) {
				System.out.println("quantity");
				qyt=s.nextInt();
				bill=bill+nonveg[q]*qyt;
				System.out.println(bill);

				String foodName = food[q];
				int quantity =qyt;
				int price=nonveg[q];
				b[count]=new Bills(foodName,quantity,price);
				count++;
			}

		}while(q!=0);
	}
	public void veg() {
		int q;
		do{
			System.out.println("                  Veg Pizza Menu                  |");
			System.out.println("|=================================================|");
			System.out.println("|            PizzaName                Price       |");
			System.out.println("|          1.Onion                    159/-       |");
			System.out.println("|          2.Cheese                   219/-       |");
			System.out.println("|          3.Maximus                  239/-       |");
			System.out.println("|          4.Dominator                219/-       |");
			System.out.println("|          5.Sausage                  229/-       |");
			System.out.println("|          6.Pepperoni                329/-       |");
			System.out.println("|          7.Tikka                    439/-       |");
			System.out.println("|          8.Golden Corn              219/-       |");
			System.out.println("|          9.Tomato                   329/-       |");
			System.out.println("|          10.Capssicum               129/-       |");
			System.out.println("|                                                 |");
			System.out.println("|          Press 0 To Select Other                |");
			System.out.println("|=================================================|");

			int[] veg= {0,159,219,239,219,229,329,439,219,329,129};
			String[] food= {null,"Onion","Cheese","Maximus","Dominator","Sausage","Pepperoni","Tikka","Golden Corn","Tomato","Capssicum"};
			int[] Id= {0,1,2,3,4,5,6,7,8,9,10};
			q=s.nextInt();
			if(Id[q]==q && Id[q]!=0) {
				System.out.println("quantity");
				qyt=s.nextInt();
				bill=bill+veg[q]*qyt;
				System.out.println(bill);

				String foodName = food[q];
				int quantity =qyt;
				int price=veg[q];
				b[count]=new Bills(foodName,quantity,price);
				count++;
			}

		}while(q!=0);
	}
	public void dess() {
		int q;
		do{
			System.out.println("             Dessert And Side Menu                |");
			System.out.println("|=================================================|");
			System.out.println("|            DishName                 Price       |");
			System.out.println("|          1.Coke                      59/-       |");
			System.out.println("|          2.Sprite                    49/-       |");
			System.out.println("|          3.Choco lava cake          399/-       |");
			System.out.println("|          4.Red Velvet cake          369/-       |");
			System.out.println("|          5.Mousse cake              209/-       |");
			System.out.println("|          6.Garlic Bread Stick       169/-       |");
			System.out.println("|          7.Cheesy dips               29/-       |");
			System.out.println("|          8.Potato cheese shot        79/-       |");
			System.out.println("|          9.Fries                    149/-       |");
			System.out.println("|          10.Zingi                    49/-       |");
			System.out.println("|                                                 |");
			System.out.println("|          Press 0 To Select Other                |");
			System.out.println("|=================================================|");

			int[] dess= {0,59,49,399,369,209,169,29,79,149,49};
			String[] food= {null,"Coke","Sprite","Choco lava cake","Red Velvet cake","Mousse cake","Garlic Bread Stick","Cheesy dips","Potato cheese shot","Fries","Zingi"};
			int[] Id= {0,1,2,3,4,5,6,7,8,9,10};
			q=s.nextInt();
			if(Id[q]==q && Id[q]!=0) {
				System.out.println("quantity");
				qyt=s.nextInt();
				bill=bill+dess[q]*qyt;
				System.out.println(bill);

				String foodName = food[q];
				int quantity =qyt;
				int price=dess[q];
				b[count]=new Bills(foodName,quantity,price);
				count++;
			}

		}while(q!=0);
	}
	public void bill() {
		for(int i=0;i<b.length;i++) {
			if(b[i]!=null) {
				System.out.println(b[i]);

				System.out.println("Press 1 For Place Your Order");
				int p=s.nextInt();
				System.out.println("Your Order Has Been Placed");

			}
		}
	}

}

package hotel;

import java.util.Scanner;

public class Hotel {

	int PhoneNumber;
	String Name,Email,Address,Password;
	
	double bill=0;
	int qyt=0;
	
	Food f= new Food();
	User[] u=new User[10];
	
	
	int choice=0;
	int choice1=0;
	int choice2=0;
	int choice3=0;
	int count=0;
	int a;
	
	Scanner s=new Scanner(System.in);

	
	void call() {
		do{
			System.out.println("****************WELCOME TO DOMINO'S***************");
			System.out.println("|=================================================|");
			System.out.println("|                  1.Register                     |");
			System.out.println("|                  2.Login                        |");
			System.out.println("|                  0.Exit                         |");
			System.out.println("|                                                 |");
			System.out.println("|=================================================|");

			choice=s.nextInt();
			switch(choice) {
			case 1:

				System.out.println("|               Enter Phone Number                |");
				PhoneNumber=s.nextInt();
				System.out.println("|               Enter Your Name                   |");
				Name=s.next();
				System.out.println("|               Enter Your Address                |");
				Address=s.next();
				System.out.println("|               Enter Your Email                  |");
				Email=s.next();		
				System.out.println("|               Enter Your Password               |");
				Password=s.next();
				u[count]= new User(PhoneNumber,Name,Address,Email,Password);
				count++;
				break;
			case 2:
				System.out.println("|               Enter Email                       |");
				Email=s.next();
				System.out.println("|               Enter Password                    |");
				Password=s.next();
				for(int i=0;i<count;i++) {
					if(u[i].getEmail().equals(Email) && u[i].getPassword().equals(Password)) {

						System.out.println("****************WELCOME TO DOMINO'S***************");
						System.out.println("               Press 1 for Dine-in                ");
						System.out.println("               Press 2 for Delivery               ");
						choice1=s.nextInt();
						do {
							switch(choice1) {

							case 1: 
								System.out.println("|              Press 1 for NonVeg                |");
								System.out.println("|              Press 2 for Veg                   |");
								System.out.println("|              Press 3 Side                      |");
								System.out.println("|              Press 4 for View Cart             |");
								System.out.println("|              Press 0 for exit                  |");
								choice2=s.nextInt();
								switch(choice2) {
								case 1:
									f.nonveg();
									break;
								case 2:
									f.veg();
									break;
								case 3:
									f.dess();
									break;
								case 4:
									f.bill();
								}

							case 2:	
								System.out.println("|              Press 1 for NonVeg                |");
								System.out.println("|              Press 2 for Veg                   |");
								System.out.println("|              Press 3 Side                      |");
								System.out.println("|              Press 4 for View Cart             |");
								System.out.println("|              Press 0 for exit                  |");
								choice2=s.nextInt();
								switch(choice2) {
								case 1:
									f.nonveg();
									break;
								case 2:
									f.veg();
									break;
								case 3:
									f.dess();
									break;
								case 4:
									f.bill();
									
								}

							}
						}while(choice1!=0);
					}

					else {
						System.out.println("re enter");
					}

				}break;

			}
		}while(choice!=0);

	}

	public static void main(String[] args) {
		Hotel h = new Hotel();
		h.call();


	}

	
}
